// Player.h : main header file for the PLAYER application
//

#if !defined(AFX_PLAYER_H__9EEAF06C_7C95_4286_A93A_C75533E9ED75__INCLUDED_)
#define AFX_PLAYER_H__9EEAF06C_7C95_4286_A93A_C75533E9ED75__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif 

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		



class CPlayerApp : public CWinApp
{
public:
	CPlayerApp();


	public:
	virtual BOOL InitInstance();

	DECLARE_MESSAGE_MAP()
};



#endif
