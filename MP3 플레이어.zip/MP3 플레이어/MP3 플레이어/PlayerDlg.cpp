// PlayerDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Player.h"
#include "PlayerDlg.h"
#include "MediaPlayer.h"
#include <io.h>
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


class CAboutDlg : public CDialog
{
public:
	CAboutDlg();


	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    



protected:

	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{

}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);

}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)

END_MESSAGE_MAP()



CPlayerDlg::CPlayerDlg(CWnd* pParent )
	: CDialog(CPlayerDlg::IDD, pParent)
{
	
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CPlayerDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);

	DDX_Control(pDX, IDC_SOUND, m_Volume);
	DDX_Control(pDX, IDC_PLAYLIST, m_List);
	DDX_Control(pDX, IDC_TRACKFINDER, m_TrackFinder);
}

BEGIN_MESSAGE_MAP(CPlayerDlg, CDialog)

	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_FILE_OPEN, OnFileOpen)
	ON_BN_CLICKED(IDC_PLAY, OnPlay)
	ON_BN_CLICKED(IDC_STOP, OnStop)
	ON_NOTIFY(NM_CLICK, IDC_PLAYLIST, OnClickPlaylist)
	ON_NOTIFY(LVN_ITEMCHANGED, IDC_PLAYLIST, OnItemchangedPlaylist)
	ON_NOTIFY(NM_DBLCLK, IDC_PLAYLIST, OnDblclkPlaylist)
	ON_BN_CLICKED(IDC_DELETE, OnDelete)
	ON_NOTIFY(NM_RELEASEDCAPTURE, IDC_SOUND, OnReleasedcaptureSound)
	ON_MESSAGE(WM_MEDIAPLAYER_NOTIFY, OnUserDefinedMessage)

	
ON_BN_CLICKED(IDC_PAUSE, &CPlayerDlg::OnPause)
ON_WM_HSCROLL()
ON_NOTIFY(NM_RELEASEDCAPTURE, IDC_TRACKFINDER, &CPlayerDlg::OnReleasedcaptureTrackfinder)
ON_WM_TIMER()
ON_BN_CLICKED(IDC_RANDOM, &CPlayerDlg::OnClickedRandom)
ON_BN_CLICKED(IDC_REAPEAT, &CPlayerDlg::OnClickedReapeat)
END_MESSAGE_MAP()



BOOL CPlayerDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	m_nPlayMode = 0;
	

	SetIcon(m_hIcon, TRUE);			
	SetIcon(m_hIcon, FALSE);		
	strcpy(m_strFileName,"");
	InitListCtrl();
	InitVolumn();
	MP3=NULL;

	InitTrackBar();
	SetTimer(1, 500, NULL);
	

	GetDlgItem(IDC_PLAY)->EnableWindow(FALSE);
	GetDlgItem(IDC_STOP)->EnableWindow(FALSE);
	GetDlgItem(IDC_PAUSE)->EnableWindow(FALSE);
	



	
	
	return TRUE;  
}

void CPlayerDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}



void CPlayerDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); 

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);


		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

	
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}


HCURSOR CPlayerDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CPlayerDlg::OnFileOpen()
{
	CString PathName;
	CString FileName;


	CFileDialog dlg(TRUE, _T("MP3"), _T("*.MP3"), OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
		_T("Audio Files (*.MP3)|*.MP3|Wave Files (*.WAV)|*.WAV|All Files (*.*)|*.*||"));
	if (dlg.DoModal() == IDOK)
	{
		PathName = dlg.GetPathName(); 
		FileName = dlg.GetFileName(); 

		lstrcpy((LPSTR)m_strPathName, (LPSTR)PathName.operator const char* ());
		lstrcpy((LPSTR)m_strFileName, (LPSTR)FileName.operator const char* ());


		TotalCnt = m_List.GetItemCount();
		lvitem.mask = LVIF_TEXT;
		lvitem.iItem = TotalCnt;
		lvitem.iSubItem = 0;
		lvitem.pszText = m_strFileName;
		m_List.InsertItem(&lvitem);

		lvitem.iSubItem = 1;
		lvitem.pszText = m_strPathName;
		m_List.SetItem(&lvitem);

	
		if (MP3)
		{
			MP3->Open((LPSTR)(LPCTSTR)PathName);
			MP3->Stop();
		}
		GetDlgItem(IDC_PLAY)->EnableWindow(TRUE);
		GetDlgItem(IDC_STOP)->EnableWindow(TRUE);
	}
}

void CPlayerDlg::OnPlay()
{
	OnStop(); 

	
	if (!MP3)
	{
		MP3 = new CMediaPlayer;
		MP3->Init(m_hWnd, WM_MEDIAPLAYER_NOTIFY);
	}
	if (m_nPlayMode == 2 && m_List.GetItemCount() > 0) 
	{
		int randomIndex = rand() % m_List.GetItemCount(); 
		m_List.GetItemText(randomIndex, 1, m_strPathName, 256);
	}


	MP3->Open((LPSTR)m_strPathName);
	MP3->Play();

	// ���� �ʱ�ȭ
	int nVolume = m_Volume.GetPos();
	MP3->SetVolume(nVolume);


	// ��ư Ȱ��ȭ
	GetDlgItem(IDC_STOP)->EnableWindow(TRUE);
	GetDlgItem(IDC_PAUSE)->EnableWindow(TRUE);
}



void CPlayerDlg::OnStop()
{
	if (MP3 != NULL)
	{
		MP3->Stop();
		MP3->StopVideo();
		delete MP3;
		MP3 = NULL;

		m_TrackFinder.SetPos(0);
		OutputDebugString(_T("����� �����Ǿ����ϴ�.\n"));
	}
	if (m_nPlayMode == 1)
	{
		OnPlay();
	}
}

BOOL CPlayerDlg::DestroyWindow()
{
	OnStop();
	KillTimer(1);
	return CDialog::DestroyWindow();
}

void CPlayerDlg::InitListCtrl()
{
	lvcolumn.mask = LVCF_FMT | LVCF_SUBITEM | LVCF_TEXT | LVCF_WIDTH;
	lvcolumn.fmt = LVCFMT_LEFT;
	lvcolumn.pszText = "FileName";
	lvcolumn.iSubItem = 0;
	lvcolumn.cx = 80;
	m_List.InsertColumn(0, &lvcolumn);

	lvcolumn.mask = LVCF_FMT | LVCF_SUBITEM | LVCF_TEXT | LVCF_WIDTH;
	lvcolumn.fmt = LVCFMT_LEFT;
	lvcolumn.pszText = "PathName";
	lvcolumn.iSubItem = 1;
	lvcolumn.cx = 80;
	m_List.InsertColumn(1, &lvcolumn);
}

void CPlayerDlg::OnClickPlaylist(NMHDR* pNMHDR, LRESULT* pResult)
{
	m_List.GetItemText(DataNum, 1, m_strPathName, 256);
	*pResult = 0;
}

void CPlayerDlg::OnItemchangedPlaylist(NMHDR* pNMHDR, LRESULT* pResult)
{
	NM_LISTVIEW* pNMListView = (NM_LISTVIEW*)pNMHDR;

	DataNum = pNMListView->iItem;
	*pResult = 0;
}

void CPlayerDlg::OnDblclkPlaylist(NMHDR* pNMHDR, LRESULT* pResult)
{
	OnStop();
	OnPlay();
	*pResult = 0;
}

void CPlayerDlg::OnDelete()
{
	if (!m_List.GetItemCount())
	{
		AfxMessageBox("������ ����Ʈ�� �����ϴ�!!");
		return;
	}
	if (MP3->GetState())
	{
		if (MP3->GetState() == PLAY)
		{
			if (!strcmp(MP3->GetPlayFile(), m_strPathName))
			{
				AfxMessageBox("������ ������Դϴ�.");
				return;
			}
		}
	}
	m_List.DeleteItem(DataNum);
}

void CPlayerDlg::InitVolumn()
{
	m_Volume.SetRange(0, 100);
	m_Volume.SetPageSize(10);
	m_Volume.SetPos(50);
}

void CPlayerDlg::OnReleasedcaptureSound(NMHDR* pNMHDR, LRESULT* pResult)
{
	int nVolume = m_Volume.GetPos();
	CString debugMsg;
	debugMsg.Format(_T("Slider Volume: %d\n"), nVolume);
	OutputDebugString(debugMsg);

	if (MP3 != NULL)
	{
		MP3->SetVolume(nVolume);
	}
	*pResult = 0;
}

BOOL CPlayerDlg::OnCommand(WPARAM wParam, LPARAM lParam)
{
	return CDialog::OnCommand(wParam, lParam);
}

LRESULT CPlayerDlg::OnUserDefinedMessage(WPARAM wParam, LPARAM lParam)
{
	return 0;
}

void CPlayerDlg::OnPause()
{
	if (MP3 != NULL)
	{
		if (MP3->IsPause())
		{
			MP3->Play();
			GetDlgItem(IDC_PAUSE)->SetWindowText(_T("||"));
		}
		else
		{
			MP3->Pause();
			GetDlgItem(IDC_PAUSE)->SetWindowText(_T("||"));
		}
	}
}

void CPlayerDlg::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{
	if (pScrollBar == (CScrollBar*)&m_Volume)
	{
		int nVolume = m_Volume.GetPos();
		CString debugMsg;
		debugMsg.Format(_T("Slider moved. Volume: %d\n"), nVolume);
		OutputDebugString(debugMsg);

		if (MP3 != NULL)
		{
			MP3->SetVolume(nVolume);
		}
		else
		{
			OutputDebugString(_T("MP3 object is NULL.\n"));
		}
	}
	CDialog::OnHScroll(nSBCode, nPos, pScrollBar);
}

void CPlayerDlg::InitTrackBar()
{
	m_TrackFinder.SetRange(0, 100);
	m_TrackFinder.SetPos(0);
}

void CPlayerDlg::OnReleasedcaptureTrackfinder(NMHDR* pNMHDR, LRESULT* pResult)
{
	if (MP3)
	{
		int trackPos = m_TrackFinder.GetPos();

		long duration = MP3->GetDuration();
		if (duration > 0)
		{
			long newPosition = static_cast<long>((trackPos * duration) / 100);
			MP3->Seek(newPosition);
			MP3->SeekVideo(newPosition);
		}
	}
	*pResult = 0;
}

void CPlayerDlg::OnTimer(UINT_PTR nIDEvent)
{
	if (nIDEvent == 1 && MP3)
	{
		long duration = MP3->GetDuration();
		long currentPosition = MP3->GetCurrentPosition();

		if (duration > 0)
		{
			int trackPos = static_cast<int>((currentPosition * 100) / duration);
			m_TrackFinder.SetPos(trackPos);
		}
	}
	CDialog::OnTimer(nIDEvent);
}

void CPlayerDlg::OnClickedRandom()
{
	m_nPlayMode = 2;
}

void CPlayerDlg::OnClickedReapeat()
{
	m_nPlayMode = 1;
}
