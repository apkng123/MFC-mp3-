#include "stdafx.h"
#include "MediaPlayer.h"
#include <dshow.h>
#include <atlbase.h>

CMediaPlayer::CMediaPlayer()
{
    p_BasicAudio = NULL;
    m_state = STOP;
    p_GraphBuilder = NULL;
    p_MediaControl = NULL;
    p_MediaEvent = NULL;
    p_MediaSeeking = NULL;
    p_SrcCur = NULL;
    p_SrcNext = NULL;
}

CMediaPlayer::~CMediaPlayer()
{
    SAFE_RELEASE(p_BasicAudio);
    SAFE_RELEASE(p_GraphBuilder);
    SAFE_RELEASE(p_MediaControl);
    SAFE_RELEASE(p_MediaEvent);
    SAFE_RELEASE(p_MediaSeeking);
    SAFE_RELEASE(p_SrcCur);
    SAFE_RELEASE(p_SrcNext);
    CoUninitialize();
}

void CMediaPlayer::Init(HWND hWnd, UINT uiMsg)
{
    CoInitialize(NULL);

    HRESULT hr = CoCreateInstance(CLSID_FilterGraph, NULL, CLSCTX_INPROC_SERVER, IID_IGraphBuilder, (void**)&p_GraphBuilder);
    if (SUCCEEDED(hr))
    {
        p_GraphBuilder->QueryInterface(IID_IMediaControl, (void**)&p_MediaControl);
        p_GraphBuilder->QueryInterface(IID_IMediaEvent, (void**)&p_MediaEvent);
        p_GraphBuilder->QueryInterface(IID_IMediaSeeking, (void**)&p_MediaSeeking);

        hr = p_GraphBuilder->QueryInterface(IID_IBasicAudio, (void**)&p_BasicAudio);
        if (FAILED(hr))
        {
            OutputDebugString(_T("Failed to initialize IBasicAudio. Audio will not work.\n"));
            p_BasicAudio = NULL;
        }
        else
        {
            OutputDebugString(_T("IBasicAudio initialized successfully.\n"));
        }
    }

    if (p_MediaEvent)
    {
        p_MediaEvent->SetNotifyWindow((OAHWND)hWnd, uiMsg, 0);
    }
}

void CMediaPlayer::Open(const char* szFileName)
{
    WCHAR wszName[256];
    MultiByteToWideChar(CP_ACP, 0, szFileName, -1, wszName, 256);
    p_GraphBuilder->RenderFile(wszName, NULL);
    strcpy(m_strPathName, szFileName);
}

bool CMediaPlayer::Play()
{
    if (!p_MediaControl)
        return false;

    HRESULT hr = p_MediaControl->Run();
    if (FAILED(hr))
    {
        OutputDebugString(_T("Failed to set graph to RUN state.\n"));
        return false;
    }

    OutputDebugString(_T("Media Player is now in PLAY state.\n"));
    m_state = PLAY;
    return true;
}

void CMediaPlayer::Pause()
{
    if (p_MediaControl)
    {
        HRESULT hr = p_MediaControl->Pause();
        if (SUCCEEDED(hr))
        {
            m_state = PAUSE;
        }
    }
}

void CMediaPlayer::Stop()
{
    if (!p_MediaControl)
        return;
    p_MediaControl->Stop();
    m_state = STOP;
    LONGLONG pos = 0;
    p_MediaSeeking->SetPositions(&pos, AM_SEEKING_AbsolutePositioning, NULL, AM_SEEKING_NoPositioning);
}

int CMediaPlayer::GetState()
{
    if (this == NULL)
    {
        return STOP;
    }
    return m_state;
}

char* CMediaPlayer::GetPlayFile()
{
    return m_strPathName;
}

bool CMediaPlayer::IsPause()
{
    return m_state == PAUSE;
}

void CMediaPlayer::SetVolume(int volume)
{
    if (p_BasicAudio)
    {
        long lVolume;
        if (volume == 0)
        {
            lVolume = -10000;
        }
        else
        {
            lVolume = -5000 + (volume * 50);
        }

        HRESULT hr = p_BasicAudio->put_Volume(lVolume);
        if (FAILED(hr))
        {
            OutputDebugString(_T("Failed to set volume.\n"));
        }
    }
}

long CMediaPlayer::GetDuration()
{
    if (p_MediaSeeking)
    {
        LONGLONG duration = 0;
        if (SUCCEEDED(p_MediaSeeking->GetDuration(&duration)))
        {
            return static_cast<long>(duration / 10000);
        }
    }
    return 0;
}

long CMediaPlayer::GetCurrentPosition()
{
    if (p_MediaSeeking)
    {
        LONGLONG currentPosition = 0;
        if (SUCCEEDED(p_MediaSeeking->GetCurrentPosition(&currentPosition)))
        {
            return static_cast<long>(currentPosition / 10000);
        }
    }
    return 0;
}

void CMediaPlayer::Seek(long position)
{
    if (p_MediaSeeking)
    {
        LONGLONG newPosition = position * 10000;
        p_MediaSeeking->SetPositions(&newPosition, AM_SEEKING_AbsolutePositioning, NULL, AM_SEEKING_NoPositioning);
    }
}

void CMediaPlayer::OpenVideo(const char* videoPath)
{
    if (!p_GraphBuilder)
    {
        OutputDebugString(_T("p_GraphBuilder�� �ʱ�ȭ���� �ʾҽ��ϴ�. OpenVideo ����.\n"));
        return;
    }

    WCHAR wszFilePath[MAX_PATH];
    MultiByteToWideChar(CP_ACP, 0, videoPath, -1, wszFilePath, MAX_PATH);

    HRESULT hr = p_GraphBuilder->RenderFile(wszFilePath, NULL);
    if (FAILED(hr))
    {
        OutputDebugString(_T("RenderFile ����: ������ ������ �� �� �����ϴ�.\n"));
        return;
    }

    OutputDebugString(_T("������ ������ ���������� �������ϴ�.\n"));
}

void CMediaPlayer::PlayVideo()
{
    if (p_MediaControl)
    {
        p_MediaControl->Run();
    }
}

void CMediaPlayer::PauseVideo()
{
    if (p_MediaControl)
    {
        p_MediaControl->Pause();
    }
}

void CMediaPlayer::StopVideo()
{
    if (p_MediaControl)
    {
        p_MediaControl->Stop();
        LONGLONG pos = 0;
        if (p_MediaSeeking)
        {
            p_MediaSeeking->SetPositions(&pos, AM_SEEKING_AbsolutePositioning, NULL, AM_SEEKING_NoPositioning);
        }
    }
}

void CMediaPlayer::SeekVideo(long position)
{
    if (p_MediaSeeking)
    {
        LONGLONG pos = position * 10000;
        p_MediaSeeking->SetPositions(&pos, AM_SEEKING_AbsolutePositioning, NULL, AM_SEEKING_NoPositioning);
    }
}

HRESULT CMediaPlayer::SetVideoWindow(HWND hWnd)
{
    if (!p_GraphBuilder)
    {
        OutputDebugString(_T("p_GraphBuilder�� NULL�Դϴ�. �׷����� �ʱ�ȭ���� �ʾҽ��ϴ�.\n"));
        return E_FAIL;
    }

    if (!p_VideoWindow)
    {
        HRESULT hr = p_GraphBuilder->QueryInterface(IID_IVideoWindow, (void**)&p_VideoWindow);
        if (FAILED(hr) || !p_VideoWindow)
        {
            OutputDebugString(_T("IVideoWindow �������̽� �������� ����\n"));
            return hr;
        }
    }

    HRESULT hr = p_VideoWindow->put_Owner((OAHWND)hWnd);
    if (FAILED(hr))
    {
        OutputDebugString(_T("put_Owner ����: ���� ������ ���� ����.\n"));
        return hr;
    }

    hr = p_VideoWindow->put_WindowStyle(WS_CHILD | WS_CLIPSIBLINGS);
    if (FAILED(hr))
    {
        OutputDebugString(_T("put_WindowStyle ����: ���� ������ ��Ÿ�� ���� ����.\n"));
        return hr;
    }

    RECT rect;
    GetClientRect(hWnd, &rect);
    hr = p_VideoWindow->SetWindowPosition(0, 0, rect.right, rect.bottom);
    if (FAILED(hr))
    {
        OutputDebugString(_T("SetWindowPosition ����: ���� ������ ��ġ ���� ����.\n"));
        return hr;
    }

    OutputDebugString(_T("���� ������ ���� ����.\n"));
    return S_OK;
}
