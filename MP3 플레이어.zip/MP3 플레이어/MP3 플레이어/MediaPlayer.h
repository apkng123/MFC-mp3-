#ifndef AFX_MEDIAPLAYER_H__83F8DCC7_059B_4A46_B729_4D21DBD5DF57__INCLUDED_
#define AFX_MEDIAPLAYER_H__83F8DCC7_059B_4A46_B729_4D21DBD5DF57__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <Dshow.h>
#include <tchar.h>

#define SAFE_RELEASE(p)           {if (p) p->Release();p=NULL;}
#define WM_MEDIAPLAYER_NOTIFY      WM_USER+100
#define STOP 0
#define PLAY 1
#define PAUSE 2

class CMediaPlayer
{
public:
    CMediaPlayer();
    virtual ~CMediaPlayer();

    void Init(HWND hWnd, UINT uiMsg);
    void Open(const char* szFileName);
    bool Play();
    void Pause();
    void Stop();
    int GetState();
    char* GetPlayFile();
    bool WMNotify();
    bool Replay();
    bool IsPause();
    void SetVolume(int volume);
    long GetDuration();
    long GetCurrentPosition();
    void Seek(long position);
    void OpenVideo(const char* videoPath);
    void PlayVideo();
    void PauseVideo();
    void StopVideo();
    void SeekVideo(long position);
    HRESULT SetVideoWindow(HWND hwnd);



private:
    IGraphBuilder* p_GraphBuilder;
    IMediaControl* p_MediaControl;
    IMediaEventEx* p_MediaEvent;
    IMediaSeeking* p_MediaSeeking;
    IBaseFilter* p_SrcCur;
    IBaseFilter* p_SrcNext;
    IBasicAudio* p_BasicAudio; 
    CComPtr<IVideoWindow> p_VideoWindow;

    BYTE m_state;
    char m_strPathName[255];
};

#endif 